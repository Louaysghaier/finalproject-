import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  //private baseUrl = 'http://localhost:8081/api/auth';
 private signupUrl = 'http://localhost:8081/api/auth/signup/employee';
 private signupUrl1 = 'http://localhost:8081/api/auth/signIn';

  constructor(private http: HttpClient) { }

  authenticateUser(email: string, password: string) {
    const body = { username: email, password };
    return this.http.post<any>(this.signupUrl1, body).pipe(
      tap((response) => {
        
           
      }),
      catchError((error: HttpErrorResponse) => {
        // Handle errors
        if (error.status === 401) {
          console.error('Authentication failed. Invalid username or password.');
        } else {
          console.error('An error occurred during authentication.', error);
        }
        return throwError('Authentication failed.');
      })
    );
  }

  login(email: string, password: string, rememberMe: boolean): Observable<any> {
    return this.http.post<any>(this.signupUrl1, { email, password }).pipe(
      tap((response) => {
        const token = response.accessToken; // Assuming the token property is named "accessToken"
        const tokenWithPrefix = `Bearer ${token}`;
                if (rememberMe) {
          localStorage.setItem('access_token', tokenWithPrefix);
        } else {
          sessionStorage.setItem('access_token', tokenWithPrefix);
        }
      }),
      catchError((error: HttpErrorResponse) => {
        // Handle errors
        if (error) {
        
          console.error('An error occurred during authentication.', error);

        }
        return throwError('Authentication failed.');
      })
    );
  }
 
  signupEmployee(user: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    return this.http.post<any>(this.signupUrl, user, httpOptions)
    .pipe(
      catchError(error => {
        console.error('An error occurred:', error);
        return throwError(error);
      })
    );
};
  isLoggedIn(): boolean {
    return true;
   // return !!localStorage.getItem('access_token') || !!sessionStorage.getItem('access_token');
    
  }



  
}
