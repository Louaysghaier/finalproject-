import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/login/auth.service';
@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
    test : Date = new Date();
    focus: boolean = false;
    focus1: boolean = false;
    focus2: boolean = false;
    agreePrivacy: boolean = false;
    user = {
      name: '',
      username: '',
      email: '',
      password: ''
    };
    signupError: string = '';
  
    constructor(private authService: AuthService, private router: Router) { }
    ngOnInit() {}
    onSubmit(signupForm: NgForm) {
        if (signupForm.valid && this.agreePrivacy) {
          const user = {
            name: this.user.name,
            username: this.user.username, // Match the property name in your backend entity
            email: this.user.email,
            password: this.user.password,
            blocked: false, // Set to appropriate value
            address: 'TUNISIA', // Set to appropriate value
            valid: false // Set to appropriate value
          };
      
          this.authService.signupEmployee(user).subscribe(
            (response) => {
              console.log('User registered successfully!');
              // Update this part based on your backend response
              if (response && response.jwtToken) {
                const token = response.jwtToken;
                // Save token to local storage or session storage
                localStorage.setItem('token', token);
              }
              this.router.navigate(['/dashboard_employee']);
              alert('Welcome to our platform!');
            },
            (error) => {
              console.error('Error during registration.', error);
              alert('Error during registration. Please try again.');
              this.signupError = 'Error during registration. Please try again.';
            }
          );
        } else {
          console.log('Form is invalid or Privacy Policy not agreed.');
        }
      }
      
      
}
